"""调用 SocialClub Query API 获取玩家数据。

替代 HQSHI（空桑）作为数据源，直接使用自建的 REST API。
API 文档见 README.md — http://localhost:8686/api/player?nickname=

API 地址可通过 set_api_base_url() 配置，默认 localhost:8686。
"""
from __future__ import annotations

from typing import Any, Dict, Optional

import aiohttp

_API_BASE = "http://localhost:8686"


def set_api_base_url(url: str) -> None:
    """配置 API 地址（由插件初始化时从 config 读取）。"""
    global _API_BASE
    _API_BASE = url.rstrip("/")


class ApiError(RuntimeError):
    pass


async def _get(endpoint: str, timeout: int = 30) -> Dict[str, Any]:
    """GET 请求本地 API，返回 JSON body。"""
    url = f"{_API_BASE}{endpoint}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
                data = await resp.json()
                if data.get("code") != 200:
                    raise ApiError(data.get("message", f"HTTP {resp.status}"))
                body = data.get("body") or {}
                return body
    except aiohttp.ClientError as e:
        raise ApiError(f"API 连接失败: {e}") from e


async def check_health() -> Dict[str, Any]:
    """健康检查。"""
    url = f"{API_BASE}/health"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
            return await resp.json()


async def query_player(nickname: str, force: bool = False) -> Dict[str, Any]:
    """查询玩家完整数据：资料 + 等级金钱 + 深度统计。"""
    force_str = "&force=true" if force else ""
    return await _get(f"/api/player?nickname={nickname}{force_str}")


async def query_profile(nickname: str) -> Dict[str, Any]:
    """仅查询基础资料。"""
    body = await _get(f"/api/player/profile?nickname={nickname}")
    return body


async def query_stats(nickname: str) -> Dict[str, Any]:
    """仅查询深度统计。"""
    body = await _get(f"/api/player/stats?nickname={nickname}")
    return body


def format_career_text(body: Dict[str, Any]) -> str:
    """将 API 返回的 JSON 格式化为 QQ 消息文本（对齐空桑的输出风格）。"""
    profile = body.get("profile") or {}
    overview = body.get("overview") or {}
    stats = body.get("stats") or {}
    cats = stats.get("categories") or {}

    lines = [
        "生涯查询结果(自建)",
        f"昵称: {profile.get('nickname') or '-'}",
        f"RID: {profile.get('rockstar_id') or '-'}",
    ]

    # 等级/金钱（来自 overviewAjax）
    if overview.get("rank"):
        lines.append(f"等级: {overview['rank']}")
    if overview.get("rp"):
        lines.append(f"RP: {overview['rp']}")
    if overview.get("cash") or overview.get("bank"):
        lines.append(f"现金: {overview.get('cash') or '-'} / 银行: {overview.get('bank') or '-'}")
    if overview.get("crew_name"):
        lines.append(f"帮会: {overview['crew_name']}")

    # 所在地 + 好友
    if profile.get("country_code"):
        lines.append(f"所在地: {profile['country_code']}")
    if profile.get("friend_count"):
        lines.append(f"好友: {profile['friend_count']}")

    # 关联账号
    linked = profile.get("linked_accounts") or []
    if linked:
        linked_str = " | ".join(
            f"{a.get('service','?')}:{a.get('user_name') or a.get('user_id') or '?'}"
            for a in linked
        )
        lines.append(f"关联: {linked_str}")

    # 关键生涯统计
    career = cats.get("career") or {}
    if career:
        lines.append("─── 生涯 ───")
        key_items = [
            "总收入", "总花费", "杀死的玩家总数",
            "被其他玩家杀死的总次数", "竞赛玩家击杀/死亡比率",
        ]
        for k in key_items:
            if k in career:
                lines.append(f"{k}: {career[k]}")

    general = cats.get("general") or {}
    if general:
        key_items = [
            "角色使用时间", "制作的角色", "最后一次升级",
        ]
        for k in key_items:
            if k in general:
                lines.append(f"{k}: {general[k]}")

    skills = cats.get("skills") or {}
    if skills:
        # 只显示非 100% 的技能
        non_max = {k: v for k, v in skills.items() if "100%" not in v}
        if non_max:
            lines.append("─── 技能 ───")
            for k, v in list(non_max.items())[:5]:
                lines.append(f"{k}: {v}")

    # 缓存状态
    cached = body.get("cached", False)
    lines.append(f"\n({'缓存' if cached else '实时'}数据)")

    return "\n".join(lines)


def format_profile_text(body: Dict[str, Any]) -> str:
    """仅格式化基础资料（简短版）。"""
    profile = body if "nickname" in body else body.get("profile") or body
    overview = body.get("overview") or {}

    lines = ["玩家资料"]
    if profile.get("nickname"):
        lines.append(f"昵称: {profile['nickname']}")
    if profile.get("rockstar_id"):
        lines.append(f"RID: {profile['rockstar_id']}")
    if overview.get("rank"):
        lines.append(f"等级: {overview['rank']}")
    if profile.get("country_code"):
        lines.append(f"所在地: {profile['country_code']}")
    if profile.get("friend_count"):
        lines.append(f"好友: {profile['friend_count']}")

    primary = profile.get("primary_crew")
    if primary:
        lines.append(f"帮会: {primary['name']} [{primary['tag']}]")

    games = profile.get("games") or []
    if games:
        lines.append(f"游戏: {', '.join(g['name'] for g in games)}")

    return "\n".join(lines)
