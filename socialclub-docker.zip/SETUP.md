# 完整部署教程

---

## 一、安装环境（只需一次）

### 1. 装 Python

下载 Python 3.10 以上版本：https://www.python.org/downloads/

安装时勾选 **Add Python to PATH**。

验证：
```bash
python --version
# 应显示 Python 3.10.x 或更高  最好3.14
```

### 2. 创建虚拟环境

打开终端（PowerShell 或 CMD），进入项目目录：
```bash
cd socialclub
python -m venv .venv314
```

### 3. 安装依赖

```bash
.venv314\Scripts\python.exe -m pip install -r requirements.txt
```

---

## 二、配置 Cookie（每次 Cookie 过期时）

R星 登录凭证只有 5 分钟有效期，但服务会自动续期。**只需在首次启动或续期失败时手动操作一次。**

### 操作步骤

1. 浏览器打开 https://socialclub.rockstargames.com
2. 如果没登录，先登录你的 R星 账号
3. **按 F5 刷新页面**（这步很关键，确保拿到全新的 Cookie）
4. 按 **F12** 打开开发者工具
5. 点击 **Application**（应用程序）标签
6. 左侧找到 **Cookies** → 点击 `https://socialclub.rockstargames.com`
7. 按 **Ctrl+A** 全选 → **Ctrl+C** 复制
8. 打开项目目录下的 `cookie.txt` → **Ctrl+A** → **Ctrl+V** 粘贴覆盖 → **Ctrl+S** 保存

> ⚠️ 全程尽量在 **30 秒内**完成。Cookie 5 分钟就会过期。

---

## 三、启动服务

### 方法 1：双击启动（推荐）

直接双击 `start.bat`

### 方法 2：命令行启动

```bash
.venv314\Scripts\python.exe -m app.cli setckf cookie.txt
.venv314\Scripts\python.exe -m uvicorn app.main:app --host 0.0.0.0 --port 8686
```

### 验证启动成功

浏览器打开 http://localhost:8686/health

应该显示：
```json
{"has_token":true,"token_preview":"eyJhbGciOi...","refresh_ready":true,"missing_keys":[]}
```

---

## 四、使用

### Web 面板

打开 http://localhost:8686/ui

输入玩家昵称 → 回车。可以看到：
- 基础资料（昵称、RID、所在地、好友、帮会、游戏）
- **等级 & 金钱**（绿色卡片）
- 生涯统计（240 项，按分类展开）

### 命令行查询

```bash
.venv314\Scripts\python.exe -m app.cli query <玩家昵称>
```

### API 接口

```bash
# 完整查询
curl "http://localhost:8686/api/player?nickname=oolpploo"

# 强制刷新（跳过缓存）
curl "http://localhost:8686/api/player?nickname=oolpploo&force=true"
```

---

## 五、接入 QQ 机器人

### 前提

- 已部署 [AstrBot](https://github.com/Soulter/AstrBot)
- API 服务已启动（步骤三）

### 安装插件

1. 把 `astrbot_plugin_gta_online_helper.zip` 解压
2. 把解压出来的文件夹放到 AstrBot 的 `addons/plugins/` 目录下
3. 重启 AstrBot

### 配置

在 AstrBot 插件管理面板中，可修改：

| 配置项 | 默认值 | 说明 |
|---|---|---|
| `api_base_url` | `http://localhost:8686` | API 地址，本机不用改 |
| `battleye_server_host` | `51.89.97.102` | 战眼服务器 |
| `battleye_server_port` | `61455` | 战眼端口 |

如果 API 和机器人不在同一台机器，把 `api_base_url` 改成 API 服务器的 IP。

### 注入 Cookie 到机器人

私聊机器人发送：
```
/gta 更新ck <从浏览器复制的完整Cookie>
```

### 使用命令

| 命令 | 功能 |
|---|---|
| `查生涯 <昵称>` | 查玩家完整生涯 |
| `查战眼 <RID>` | 查封禁状态 |
| `/gta 绑定 <昵称>` | 绑定你的 GTA 名 |
| `/gta me` | 查自己的生涯+封禁 |

---

## 六、常见问题

### Q: 启动报 "cookie.txt 不存在"

先完成**第二步**，从浏览器复制 Cookie 到 `cookie.txt`。

### Q: 查询报 401 / "token 过期"

Cookie 太旧了。重新做**第二步**（F5 刷新页面 → 复制 Cookie → 运行 `start.bat`）。

### Q: 查询报 403 / 跳转 error.htm

请求太频繁触发了 R星 的防火墙。等 15-30 分钟后重试。正常使用不会触发。

### Q: 端口 8686 被占用

修改 `start.bat` 里 `--port 8686` 改成其他端口，比如 `--port 8888`。
同时修改插件配置的 `api_base_url` 为 `http://localhost:8888`。

